SILENCE — исправление импорта девушки 0.3.1

Внутри один обновлённый скрипт HoodedGirlPreparation.cs.

1. Остановить Play в Unity.
2. В Unity: Project → Assets → Characters → HoodedGirl → Editor.
3. Правой кнопкой по HoodedGirlPreparation → Reveal in Finder.
4. Из этого архива скопировать HoodedGirlPreparation.cs в открывшуюся папку
   проекта, выбрать «Заменить». Существующий .meta оставить.
5. Вернуться в Unity и дождаться компиляции.
6. SILENCE → 22 Prepare Hooded Girl Assets.
7. Только после успешного завершения 22: SILENCE → 23 Open Hooded Girl Preview.

Архив — однофайловое исправление, а не полный репозиторий.
Его не нужно выбирать для пункта 00 Update Sources From Folder.
Модели/текстуры повторно копировать не требуется.
Проверки без Unity пройдены; нативный импорт ещё нужно подтвердить в Unity.
