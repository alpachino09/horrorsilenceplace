SILENCE Human Motion 0.4.0

Останови Play. В Unity: SILENCE → 00 Update Sources From Folder.
Выбери ЭТУ распакованную папку с Assets и LocalPackages внутри, не Unity-проект.
После компиляции открой свой игровой мир с героиней, не просмотр 23.
SILENCE → 25 Human Animation Workshop → импорт исходного animation_pack_basic_motions.unitypackage
→ проверка 23 клипов → подключить к КОПИИ текущего мира.
Модели/текстуры повторно скачивать не нужно. Новый мир откроется сам.
Площадка проверки отдельная; кнопка Возврата в окне 25 снова открывает игровой мир.
Подробная инструкция: Docs/Animation/README_RU.md. Ограничения: Docs/Animation/REPORT_RU.md.
Код и исходные данные проверены в облаке. Unity Play/ILPP/сеть/качество движений ещё требуют проверки.
