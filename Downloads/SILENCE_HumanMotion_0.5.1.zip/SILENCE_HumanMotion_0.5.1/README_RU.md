SILENCE Human Motion 0.5.1

Естественные свободные руки: кисти возле бёдер, локти ближе к телу.
Исправлена геометрическая защита плеча, которая могла разводить локти.

Сохрани свой текущий игровой мир и закрой Unity. Распакуй архив в Downloads.
В стандартном macOS Terminal выполни:
bash ~/Downloads/SILENCE_HumanMotion_0.5.1/Install_Update.command
Выбери папку Unity-проекта с Assets, Packages, ProjectSettings и LocalPackages.
Установщик сохраняет backup кода, сверяет SHA-256 и оставляет .meta и ассеты.
После установки открой этот проект, дождись компиляции, нажми Play в НЫНЕШНЕМ мире.
V — проверить позу снаружи. Проверь покой без предметов, ходьбу, бег, затем F и E.
Для этой правки не нужно создавать новую копию через 27/28 или заново назначать клипы.
Подробности и границы проверки: Docs/Animation/NATURAL_ARMS_RU.md.

Если отдельно подключаешь новые текстуры ObjectiveEnvironment_Assets и движения
Kevin Iglesias: окно SILENCE → 28 Imported Textures and Human Motions.
Это отдельная операция с копией мира: Docs/Animation/IMPORTED_ASSETS_RU.md.
Сами лицензионные ассеты не входят в этот архив; используются уже импортированные на Mac.
Native Unity Play и внешний вид в облаке не проверены.
