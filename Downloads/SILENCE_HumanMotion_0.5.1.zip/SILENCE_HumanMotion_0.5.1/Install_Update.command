#!/bin/bash
# Offline source update generated from the code-only delivery manifest.
set -eu
patch_root="$(cd "$(dirname "$0")" && pwd -P)"
files=(
  Assets/Characters/HoodedGirl/Editor/HoodedGirlPreparation.cs
  Assets/Characters/HoodedGirl/Editor/Silence.HoodedGirl.Editor.asmdef
  Assets/Characters/HoodedGirl/Scripts/HoodedGirlDemo.cs
  Assets/Characters/HoodedGirl/Scripts/Silence.HoodedGirl.asmdef
  Assets/Creatures/SilencePredator/Scripts/MonsterAnimationController.cs
  Assets/_Silence/Editor/Silence.Editor.asmdef
  Assets/_Silence/Editor/SilenceInteractionDiagnostics.cs
  Assets/_Silence/Editor/SilenceMultiplayerInstaller.cs
  Assets/_Silence/Editor/SilenceProjectValidator.cs
  Assets/_Silence/Editor/SilenceSceneGenerator.cs
  Assets/_Silence/Editor/SilenceSourceUpdater.cs
  Assets/_Silence/Graphics/Runtime/CreatureModelPresentation.cs
  Assets/_Silence/Graphics/Runtime/FarmFogVolume.cs
  Assets/_Silence/Graphics/Runtime/FlashlightPresentation.cs
  Assets/_Silence/Graphics/Runtime/GraphicsQualityManager.cs
  Assets/_Silence/Graphics/Runtime/GraphicsQualityProfile.cs
  Assets/_Silence/Graphics/Runtime/LegacyRendererMask.cs
  Assets/_Silence/Graphics/Runtime/Players/CharacterAnimationActions.cs
  Assets/_Silence/Graphics/Runtime/Players/CharacterArmIKReset.cs
  Assets/_Silence/Graphics/Runtime/Players/CharacterArmPoseSafety.cs
  Assets/_Silence/Graphics/Runtime/Players/CharacterIKController.cs
  Assets/_Silence/Graphics/Runtime/Players/FootstepAnimationBridge.cs
  Assets/_Silence/Graphics/Runtime/Players/HumanMotionLab.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerAnimationProfile.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerAvatarDefinition.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerAvatarFace.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerAvatarPresentation.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerAvatarVisibility.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerCameraRig.cs
  Assets/_Silence/Graphics/Runtime/Players/PlayerFootContacts.cs
  Assets/_Silence/Graphics/Runtime/Silence.Graphics.asmdef
  Assets/_Silence/Graphics/Runtime/VesperGamePresentation.cs
  Assets/_Silence/Graphics/Runtime/VisualAtmosphere.cs
  Assets/_Silence/Graphics/Runtime/VisualSettingsUI.cs
  Assets/_Silence/Scripts/AssemblyInfo.cs
  Assets/_Silence/Scripts/Audio/CreatureAudio.cs
  Assets/_Silence/Scripts/Audio/MaskingAmbientSound.cs
  Assets/_Silence/Scripts/Audio/MicrophoneNoiseMeter.cs
  Assets/_Silence/Scripts/Audio/WorldAudio.cs
  Assets/_Silence/Scripts/Config/ChapterDefinition.cs
  Assets/_Silence/Scripts/Config/GameplaySettings.cs
  Assets/_Silence/Scripts/Config/PlayerSettings.cs
  Assets/_Silence/Scripts/Core/AcousticModels.cs
  Assets/_Silence/Scripts/Core/ArmAnatomyModel.cs
  Assets/_Silence/Scripts/Core/CampaignModel.cs
  Assets/_Silence/Scripts/Core/CharacterAnimationModel.cs
  Assets/_Silence/Scripts/Core/CommandInbox.cs
  Assets/_Silence/Scripts/Core/CreatureMind.cs
  Assets/_Silence/Scripts/Core/CreatureMotionMath.cs
  Assets/_Silence/Scripts/Core/FlashlightHandMotion.cs
  Assets/_Silence/Scripts/Core/FlashlightModel.cs
  Assets/_Silence/Scripts/Core/ImportedAssetModel.cs
  Assets/_Silence/Scripts/Core/InteractionGate.cs
  Assets/_Silence/Scripts/Core/InteractionRules.cs
  Assets/_Silence/Scripts/Core/InventoryModel.cs
  Assets/_Silence/Scripts/Core/NaturalArmPostureModel.cs
  Assets/_Silence/Scripts/Core/NoiseMath.cs
  Assets/_Silence/Scripts/Core/PlayerCommand.cs
  Assets/_Silence/Scripts/Core/PlayerMotionModel.cs
  Assets/_Silence/Scripts/Core/PlayerViewModel.cs
  Assets/_Silence/Scripts/Core/SessionAdmission.cs
  Assets/_Silence/Scripts/Core/Silence.Core.asmdef
  Assets/_Silence/Scripts/Core/SkinBoundsModel.cs
  Assets/_Silence/Scripts/Core/SkinPoseModel.cs
  Assets/_Silence/Scripts/Core/SurvivalModel.cs
  Assets/_Silence/Scripts/Creatures/CreatureVisual.cs
  Assets/_Silence/Scripts/Creatures/HearingCreature.cs
  Assets/_Silence/Scripts/Creatures/RuntimeNavigation.cs
  Assets/_Silence/Scripts/Gameplay/GameplayDirector.cs
  Assets/_Silence/Scripts/Gameplay/WorldAtmosphere.cs
  Assets/_Silence/Scripts/Input/PlayerInputReader.cs
  Assets/_Silence/Scripts/Interactions/BreakableBarrier.cs
  Assets/_Silence/Scripts/Interactions/CarryableProp.cs
  Assets/_Silence/Scripts/Interactions/ChapterExit.cs
  Assets/_Silence/Scripts/Interactions/IInteractable.cs
  Assets/_Silence/Scripts/Interactions/Interactable.cs
  Assets/_Silence/Scripts/Interactions/InteractionDiagnostics.cs
  Assets/_Silence/Scripts/Interactions/InteractionScanner.cs
  Assets/_Silence/Scripts/Interactions/ItemPickup.cs
  Assets/_Silence/Scripts/Interactions/ManualDoor.cs
  Assets/_Silence/Scripts/Interactions/MissionRadio.cs
  Assets/_Silence/Scripts/Interactions/PrototypeDoor.cs
  Assets/_Silence/Scripts/Interactions/PrototypeRadio.cs
  Assets/_Silence/Scripts/Interactions/TeammateAid.cs
  Assets/_Silence/Scripts/Inventory/ItemDefinition.cs
  Assets/_Silence/Scripts/Missions/BootstrapLoader.cs
  Assets/_Silence/Scripts/Missions/PrototypeExit.cs
  Assets/_Silence/Scripts/Networking/FarmBootstrap.cs
  Assets/_Silence/Scripts/Networking/IWorldAuthority.cs
  Assets/_Silence/Scripts/Networking/OfflineWorldAuthority.cs
  Assets/_Silence/Scripts/Player/ActorGameplayInput.cs
  Assets/_Silence/Scripts/Player/FirstPersonMotor.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightAnimationController.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightArtRig.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightAudioController.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightController.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightProfile.cs
  Assets/_Silence/Scripts/Player/Flashlight/FlashlightVisuals.cs
  Assets/_Silence/Scripts/Player/IArmPoseConstraints.cs
  Assets/_Silence/Scripts/Player/ICharacterIKCoordinator.cs
  Assets/_Silence/Scripts/Player/ILeftHandIKClaim.cs
  Assets/_Silence/Scripts/Player/IPlayerViewRig.cs
  Assets/_Silence/Scripts/Player/PlayerAnimationCue.cs
  Assets/_Silence/Scripts/Player/PlayerAnimatorIK.cs
  Assets/_Silence/Scripts/Player/PlayerAvatarState.cs
  Assets/_Silence/Scripts/Player/PlayerContext.cs
  Assets/_Silence/Scripts/Player/PlayerFlashlight.cs
  Assets/_Silence/Scripts/Player/PlayerLook.cs
  Assets/_Silence/Scripts/Player/SpectatorView.cs
  Assets/_Silence/Scripts/Save/CampaignSaveStore.cs
  Assets/_Silence/Scripts/SceneQuery.cs
  Assets/_Silence/Scripts/Silence.Runtime.asmdef
  Assets/_Silence/Scripts/SoundSimulation/AcousticMaskingZone.cs
  Assets/_Silence/Scripts/SoundSimulation/AcousticOcclusion.cs
  Assets/_Silence/Scripts/SoundSimulation/NoiseEvent.cs
  Assets/_Silence/Scripts/SoundSimulation/NoiseSystem.cs
  Assets/_Silence/Scripts/SoundSimulation/SurfaceMaterial.cs
  Assets/_Silence/Scripts/UI/GameplayHud.cs
  Assets/_Silence/Scripts/UI/PrototypeHud.cs
  Assets/_Silence/Scripts/UI/PrototypePreferences.cs
  Assets/_Silence/Settings/SilenceControls.inputactions
  Assets/_Silence/Tests/AnimationEditor/CharacterReworkReferenceTests.cs
  Assets/_Silence/Tests/AnimationEditor/ImportedAssetsReferenceTests.cs
  Assets/_Silence/Tests/AnimationEditor/NativeHumanMotionTests.cs
  Assets/_Silence/Tests/AnimationEditor/PlayerViewReferenceTests.cs
  Assets/_Silence/Tests/AnimationEditor/Silence.Animation.EditorTests.asmdef
  Assets/_Silence/Tests/AnimationEditor/SkinPoseReferenceTests.cs
  Assets/_Silence/Tests/EditMode/ArmAnatomyTests.cs
  Assets/_Silence/Tests/EditMode/CharacterAnimationTests.cs
  Assets/_Silence/Tests/EditMode/CoreTests.cs
  Assets/_Silence/Tests/EditMode/FlashlightTests.cs
  Assets/_Silence/Tests/EditMode/GameplayModelTests.cs
  Assets/_Silence/Tests/EditMode/ImportedAssetTests.cs
  Assets/_Silence/Tests/EditMode/NaturalArmPostureTests.cs
  Assets/_Silence/Tests/EditMode/NetworkRulesTests.cs
  Assets/_Silence/Tests/EditMode/PlayerMotionTests.cs
  Assets/_Silence/Tests/EditMode/PlayerViewTests.cs
  Assets/_Silence/Tests/EditMode/Silence.EditModeTests.asmdef
  Assets/_Silence/Tests/EditMode/SkinBoundsTests.cs
  Assets/_Silence/Tests/EditMode/SkinPoseTests.cs
  Assets/_Silence/Tests/PlayMode/FarmSmokeTests.cs
  Assets/_Silence/Tests/PlayMode/Silence.PlayModeTests.asmdef
  LocalPackages/com.silence.multiplayer/Editor/CampaignProjectValidator.cs
  LocalPackages/com.silence.multiplayer/Editor/CampaignSceneGenerator.cs
  LocalPackages/com.silence.multiplayer/Editor/CampaignWorldBuilder.cs
  LocalPackages/com.silence.multiplayer/Editor/NetworkFarmGenerator.cs
  LocalPackages/com.silence.multiplayer/Editor/NetworkProjectValidator.cs
  LocalPackages/com.silence.multiplayer/Editor/Silence.Multiplayer.Editor.asmdef
  LocalPackages/com.silence.multiplayer/Editor/Visual/AnimationClipPreparation.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/AnimationLabBuilder.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/BasicMotionsCatalog.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/CharacterReworkPreparation.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/CharacterReworkWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/CharacterSurfaceFixer.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/CreatureArtWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/FlashlightWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/ImportedAssetCatalog.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/ImportedAssetsWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/ImportedGroundInstaller.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/ImportedMotionInstaller.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/LightingConfigurator.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/PlayerAnimationControllerBuilder.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/PlayerAnimationWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/PlayerAvatarWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/PlayerViewCalibration.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/PlayerViewWorkshop.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/Silence.Visual.Editor.asmdef
  LocalPackages/com.silence.multiplayer/Editor/Visual/SkinPoseSampler.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/TerrainBuilder.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VegetationPainter.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VesperGameInstaller.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualAssetImporter.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualAssetLibrary.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualFarmRebuilder.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualPerformanceRecorder.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualSceneValidator.cs
  LocalPackages/com.silence.multiplayer/Editor/Visual/VisualWorkshop.cs
  LocalPackages/com.silence.multiplayer/Runtime/FlashlightNetworkSync.cs
  LocalPackages/com.silence.multiplayer/Runtime/GameplayActorNetwork.cs
  LocalPackages/com.silence.multiplayer/Runtime/GameplayCreatureNetwork.cs
  LocalPackages/com.silence.multiplayer/Runtime/GameplayPackets.cs
  LocalPackages/com.silence.multiplayer/Runtime/GameplaySmokeProbe.cs
  LocalPackages/com.silence.multiplayer/Runtime/GameplayWorldNetwork.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkInteractable.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkPackets.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkPlayer.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkSession.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkSmokeProbe.cs
  LocalPackages/com.silence.multiplayer/Runtime/NetworkWorldAuthority.cs
  LocalPackages/com.silence.multiplayer/Runtime/PlayerAvatarNetwork.cs
  LocalPackages/com.silence.multiplayer/Runtime/Silence.Multiplayer.asmdef
  LocalPackages/com.silence.multiplayer/package.json
)
hashes=(
  7fd5f7d3ac2929f82426829d2a29e74c8d85bd18bbdae989f2da8b60719347e0
  c785387753bac5023751136423ff6170ed9b7d0908f3890463f157ab81ab5883
  5160d8b46c9d6544b44c3c339274659a4ad860e488bdab928a5baeb9cf363276
  6a55df594f1a566a04b30e3a3c3c8dffc24edd4b0f21b118c9a85ea0b8666cd3
  4961bca3a1290579712e3f6feaff90bef310d41c2c756c48874ee50490bce7ea
  d481a02046e50ab70747bf1e22d0457432f1db59f660916242abf17658174780
  d9d2e13449899f7d7f5ceec99d09815e809fb028517281b101806b7bcc81cd3d
  574f9f819ae13519974e5c53e7286a1060b5f7fb02543c440f2a886af351d2f4
  678b6aced9435dd79fa3aeb00e90be5d04b5afd71a996a38c1db850b6d1ccabe
  1f22e7d3176f580b01fdb8cb2a02c4af53dbeae41e59980712adc855260d88d7
  ed826c0ca5794b8569b558498974daf2b74222762c9e0ac92284522d67c2a435
  eddca830ae6d92812656c5695fa859a29d8611edb3487ac5cf0952dd3c569949
  60001d03923c8abc90ddff611272515bb5b084b5c3394d583cf62d86fbde1fbc
  8fedbda09d31e82c9c27b81fb3e39a7cbf9177d87c16e42d52431ac0d739539a
  c5329ab9e6146ce9f546cabe9cdf29944d3cea04e2e4c135b8d7a3eb331859aa
  e43e51248f27142b20e20f02078bfa7c4e04a10fc7a02e316aea401093adf4cf
  2591c46f87754e3df11ceb0a4943dfb90ecb3e7f17e2738c96b2eb266e4049fe
  de158898313b5a5ebc881cfd3d7093894aba542d7af242aa71004ee7f5281005
  a261e46959c11ee12f75e99b39657695781b76193ff2a13bb8f5594980c6e23c
  553600e6faffa102f3f1d3e8067693242e82131725ef87a80a17468cc677d6a5
  3fd2763e3630891a7ad5b9d48d18b2688b5a6bb36a764f890a49933c2888f88f
  519c64613c7914bc9fcf4f4abd138bb5c12fb413e6e281d84c77a10f346beb57
  e1f64eebe06daec19522ba81198da56d33974b766c4495247f9c033fbf0ee63b
  58f71fcd613038a211e4cfadc03543045a198e642af1f1d34aa3cb6934cd8e9c
  6913e2661d1c6c8bdde4d6445b35b030d53ce5fdde489343808bfda3558fd991
  cedc12b17ddba68463afd81f84c77dd14ed756b9790c8f4cf5cbec82b31f955a
  315d7ac65a08f93f78bfa32ed3303ba1750b004edef0cd43c39ec97bfeeb5d2e
  dd582da44b837750ea608781bffd39d3289d5c0a1411c6dbe38d0e13e8590246
  1d7dca573aef5bede020566d1be6fc2271436bcecc8013cdd9dc9a0f7da9ee23
  28908b60688fef32ba6a71f98f0f1f10a28b684b43e0899086690700498a4f74
  014f1fd68231ccf87b240f2b358fc1e3abfa34db727d73981878b90b98173244
  d8a80b16f1734db6c4a120b481eec48aca8253fcb8c8c5a1b2616106c53a2981
  6c30f90b4c40471e54d7c9755e74dcdd2c8cfa371a91121fbc9db0d15d3e6044
  1abce6c36a7d1cba849c6042bea31646df2f17bf4ede3b3e689c5f087348834d
  6fe2d85c121c77b50623ac0c0a9454b561efd07c5274b18286d992863b3f38e4
  aced3b0ee642980f00673173668ac2dc80658370d2d963b1b333454e71877a5c
  4275186128591a384d1cd12008c6d6ad2e3790dd808df5ef8539545944ac8466
  1894b7e73c8e2b6daf3a58489c9c93001b24acf435218827fb156406a1d68843
  18ade3789821ca5d40e8a673f5d2e2fa8bf85dc283d104bd769f6768e7105a92
  75d1d1d0d7132d9ec00614fc2ce891e1261383415db68beed1bba73f7a37bee3
  a02161551792864749cc4c7a86123bfcbf8650ecc92ecd4ed2d9c37c51f86837
  e62c1c9fdd468e7101bdd351edd140b01e70a710f6496c2024d26806dd412728
  ba45b0ca778db7b775e1e8a81bd6611b956c82c4b0d7ea631c71e872a2d35df5
  6f9997c501bb819dc214de9a80adae573413298c13a6812f42ea3278a87dbf90
  6b4ff7b3d025dabf8416c1b2cdc449bc41e5613be11c032c6f7771a7d4b34690
  f63deafc9a2510b71bb79db6ab94cb0a84365d7d60284e61a8b20146cb693a3e
  3051722dd975890bce28d11f145debb927c4c0d66c27321f4a07fdbdc05faabf
  af2ee3ddd227f1ba76724c3e6d4bc0a996fda655821f7455d440e859936f835d
  de7c4554c81be2c7640fc437225dfbdb499d59bbfd69033e63e8a36e918213dc
  466b5dc80beefdb2089520c81b2a40f22ca27333bba54e7e77264206d235dafb
  91afbdd58adea135f5583f0525845d8dc2bb37fd05ff5b443c212080388bed32
  d3dbc8e1e31fec0c8cfbee9420c30f71d8746b50115505e24fd697d1d472575d
  9f5339e5808f9ebab5ef940898c1940e0418a0196b06ef0726bb48d6b30ab9b8
  d9b45d6f4c7bcc6af90ffb39d083761bc5c0bc3dfd0828a3aa4eecb4f56933b7
  7fdffce2fca483bf68232669ec418e538e40c0e0eae65e0593c05fdae6c6a6f3
  f18cefd1e8bf277a722f07fd4664c713d624a72f8473fa3ba19df5a17e5a8f08
  e13b300a62ab504b6178ad8a8bdf24fe2bccf1f14b36463d762fe41fd5f1a125
  fc6d4ad2a34e6d7c02fa2c428fe2118248a3bb6aa5239591cfe1131634a4827e
  70041fdaf1e63c568e74d4af4be29ce36b239098f3e47378a453d90e61eed453
  b3606856803a3ce9cc66ee476c0376b9e15c45ebf72888d7e818b22bebd57605
  1a4ab178b37f9e03ebb38ae1acd11129dec208db632173b8148eb13352c7563c
  723a2a3679c3a56f7e4b000c10bb116971b8fe700b922be20d963f843adeb2c8
  e336e5e2b924aa1e724f6b8e446c0513c1d0ba47428e447111ac971ae3a33002
  8d118e86e09594bec6c02f71563afef2ff07b97f81c8215c8fbfe0e17e929cfc
  9d5627f2a9164f13afe915798ee87e62ac9bb4be89e66c53a29c293b5d53e5e2
  6cd2ed92167508a2df5fef5d11e29bf0c9bb6f8923ec5bc826a853cc7c6d619e
  702ff9f398735c6f54daafb570ed1e6c18c138602999095717dbd1834601b039
  4796486a49a6bfdccf53627d95762ba4ea4a7096d5e4a550f67b2c18d3a71057
  cb8525b609c910d5a72b7358fdd3ad6b62b2dccafa37d31b28fde18096c00e70
  edb50fc1afac8b33b6f705d86f3039212bcae0a058335b5adf5a987bda977da4
  c30d8ab5405886faa0fde69cb4d48364f8a80a2a6a9e015b5aac881ba53095f2
  e5b1b6820530c9a8a179217b2a6133ba3b73f3e9af3bceba722822942518ef94
  e68d9015f5694d5121ebb59dda838d914ac8cccba710cf125246745dd5e55329
  99713010063071ecaa1d46b253505fa6f1f7ce2b775089a526efd265626dec2b
  620fdb0ba0ec7a7793c5bdfcaa4a0ab2a1518794718c1253bb24843cc199f731
  0a2fa51a7dccb821b0b117ae02feb4a1a1d5f84a496f309bef8429acf0071ea1
  33149ef30f381a4c1eaf3345a99a858ca3ecd8cf6026d2391081207157329fc9
  52fbe84932996baece0dfbaaac70ee3db43fdbc81db3976df8229e73299832e0
  44dd4831754b047a2a1621afcf620011f347305a0ac40df271605e7eea8a5c4b
  fbedfdd54486a423001f1e3c1136dedc5a975b800bd1b9ca1eed192ee5243fc7
  4efb22a1ea2f340225088db7e6845d7b36245ca47b1e470fafca104f9cbce269
  95f9bd15ac91f9dbfb60b4a7b4f9039542052f27527a2b22d90eaa5d95db819b
  ea721876b70d058469cd4ec0fb35df4587423f43caace6371d91de1f94261df4
  36b2c1e4cfa37da19157c87b8679cd628680e430f3436730cf1543b8c44a7ad2
  f079baf579b25b904c37b4e0d1314d146f1f4557841136a2a630fb4fe0200cf4
  d147deaacb5cdb7ca6c5d03a4604d14018b3476235648ad8ab5b1455e63daf4d
  70824843a7e23622d0f7a8f7b4512000f20ec0c426f14e7f460245927ccf7355
  e6914f3e90cfe5af2eb7d1ea4f65ab96c655f41aae6d98b125327ff5aa481ccd
  f0a084adeb6649dc499a79dd6709305c0bcc78292ed1a213bc45e64fafc20f5f
  9a8d51ca72502ac22318fd72dd251664220e29e614e35d3991ab5d2d2020f14e
  2475607fdad0138db0c5f6d8fd4303a3af0401b7cda9f1d6fb513248c3baf9c5
  dfdab99d2eeeb9dcbbdf92eaafd9ea1b990a18c093ca4ac09492dc9a79f23e80
  f10569a939d95c48d1e5762988af9db100a71119ffebab5500c79abd3e273f6f
  f2bbf9ae35040f17bcec1abac0a3eaf868355e5ed7d7cfcaa74d700fe942e6b9
  b68b8899f2109c6229187a9e9c3542b5bcbff6776a60c3a636e1a0d30596b1a5
  a0d6300f19dfa89883e123b969ab2c4524955bcbde018a50e28612cc17bbd5fc
  fcdb9c5f9aee94677ad70933330402e86d12244bcb231a309dae9b6f606a8216
  067526b0bbe229ac895794b03aac91587f3a64c2a8cbcad7cf66d7dd73a4fc8d
  7e1eb1794723dbf63c353da0e6696c461f25f08147cd135790ad6059db3cceae
  f0d1d97f24d5221c8d54c936deb14a406e6c1e834efa7b6f406f84b3ead7149c
  b44e7c35b8c9d564fbf0e3c3d6e887ff78b0cbcbeabcc53926bfbea53edccf5f
  ea0df890a587f9ef95e729a87c29eb5c825b844619e0737ab3a1495c9e1625bc
  92007f310c5a440717a4fc8519802686a60ea4c40ea1595d332fe3511ac1920b
  69ba77eb115e9303bfcec8f25f1200adfe61715d58df9dd681dd743ee386addb
  c20a654b9a17e71c99b6c804af1685b984591fc99659cbf52d6e8dd21ef3186e
  654cf2a195ec00eccef4e6949fa6f3880489c61e8bbd02d6545911a4e10d86d9
  cdc6dc6841887376584b4f8f2fbe6cd8e4571575645c7d94e826901a33e3bce5
  18edd554867dbc19e342e8d90ef25198deee96e64889c3920f8271d1d15e24a0
  db8a60d456c785dfe77c74ca27bedc7b40d40ef31be04ab0e24b0af3da49149e
  ded719437ed25f5e51fbda76850aa51975d4c8d6328107abc093e22e869e16ae
  6c47fa1968ec5e26f0d224b82afc7120b73c8932bbf92acdb5a5f9cf4f336272
  ba73f9002b65fcddaf7fb38761942305029942474c4216f7d930ab953f28cb30
  6cd7397eda11b8e3fe4c92b2f6c6930480636634a15ac413e9adab1b0278aa62
  f06c8cd3c42759ada618172df520c2b856286f6c1d918c93bacc4a62072c19c1
  30109727b5626abd5dc99e8653d99a38730badd7cdfe1982c35426164995dfd0
  c50c2e4cdeef37a65853d7e717b6fad0edeb915e39d56dfed397347f02a1aa13
  59f374fd9373d73a190e5a477e3076db294c77f08a30beb797e7309e62fd4240
  7dcb3683e4a23c09fdca6f89f64935d3fdff57e273710cf17798a9e5e10aed12
  5c5b678f1f9ee8e517a892303574017be91a09b9381701542af98ff77ff4e9ed
  63dff4019a9ab66505de72ab116e7e29c1dde035cd2201cf1b95683cfa8ec831
  1fa634f9bc17f44b568c3d3e6eaed6cc76fdbf4897908b5834cc349a1a29aaff
  c9db537f83ccb0e5d388c6f7b4bfa76d11e47a5093aedc0869a51c673afcccd3
  3514af556e1c3fb63f09c2d6dae94e13ff475bcbd9b8d38e0f9cfffb005eac6b
  9da1b51c82a609dcf7aeadf4373ebc24ed80ed0342560a3374f62ff39d126c1a
  0b0ce8a5f6e45c9b666f457c8c92378b00fe9f32c1e7680e7293720f51db9898
  352adfc143332601f42affad380a131642ab75ac5239cfde62fabbe9b02bb1e3
  b307581d75057d83c1b456b95ba09a830e1fd2388c029f1462e8e2821e5cf4fe
  8ea41dcae55eacc63e92eca338083debb811100eef835fed10d7f1402f4c0d9b
  6dde0e0d735841dada08bb35fe3335924182f94da89ce673c04de9b2dcfb04cb
  9cdaaf4a738a1704e46f787a3a46152f532264f4e58851ac874045c703d2feed
  a4f36a7c6d3665121cdc2ead7589017afcc78efa41c239ebdab77ba95099cdce
  f701ac8a5977ae21f8ed6f5aac5cbad52fa1e35595411bf3b91d05f43bd44969
  9719ef68f191a7e4fc29e3de7b3d96139cf8e749ecdadc6b69fe24df0a9e2046
  699a98a2557d64a6a860f76e0ba24dae358da83581b5cfba188f4916ee4e64a5
  cd511dc9606b6979dab763481d53539bd503a3840a98669b63ab526c0383e545
  a44bef6e537b19b05a0e9d2857a29e71e83e2710d496735d5a88b4669b541d85
  b3366ddbc454c3eafdc608ff043e53619266b980377793c0f172c88e4282574e
  decd15d61e69d618e01cc6d93d073cdfbcb2ebfeaa27c6c384bd4ff22304c351
  ff507e50141b6cc8339fd2e4a74d15db4c3eb54d5d0ca48d053028694e1a3947
  c5ea0f3a3f061ded2ae1946ed7c3f18c10a0a48abdf88bb8789c630ff8a7da66
  6e9a0e964295e5ff1402b748713ecc8e9e132a5ab2e7a73b4f6c162985966336
  3977507a747a26f5f066112117bc249e39aa02935a9b26cfbd087f4fbc732d94
  917e266820485343455c6726f78258d41ecad82a3758f6d9c64607abf2290c63
  a7d4474bb3079125f0e1b559228cbd4ca99c6f13fa4983e5f5e523360048f300
  68652773caa3bd20619367074337c863373c089d9028b53c39e469ab8188e046
  57f65f8f5d7e91479674e3bfdf691fca1eb1ac93564426b789ef3fcbd27d78ed
  c18a709c6d9e3be56defaa2a97616245fd77b7edf692220c257d70fc986394fa
  78533d59fec27b7714ba0ce9366af70aa4b1885948bce54d191240a7f3c7211e
  826c256fcc35ed7534ef25686a928f68cac4210a5dc7cef966ac7ccb46916517
  0219b6dbd06ab9827f2ab61b628f00a8aaab516bd354182284618b966c0a0cee
  17cb5f30ee5c7edde0a36d61f9b0f431841491de02f0be81e1c85816945e50d8
  4fa400b73881a39a31c8e2aa3ddf49e56f0f00b23e453f9ce37798c57381aa2b
  e35484956e6db69753cbadf94a349e157a3501829b2d4157d4b06719e58c2937
  0663422424b5000be035044c3170cc21192d7474a85e1105e173216cf64d60c3
  0e5a867da6eb035905c6681b64065461510b6822cb3ec005deccbed01f39c633
  21ac789b3431273c3ff597c3c1f27da34ad62aaa40ad61fdc0feb439ac68ef9b
  c4298a8034496a206cdb26ab239e04d2c6678dc218228f83bbfb8e83294e0c79
  798cbb696574554653c519a7ab560323b095855a7ed6ff8774eeab93f8114d68
  4787dad69a9e5e5b286dda8012cf069d0a2627e90e5fc7affc1b33a57c79e501
  ed12502646fc73589b0fc6260b0a88364cf0c30593bc82fdea168d107b4555a5
  352e3977c0eb930220458baf2ccd3c7693eaf9064939a29b3cd29874132a982a
  dee69f1acb9a5d7303775d32d94353f34d878a1ecb3d56ff25ef6c23e08bf89a
  cbb6e221287b939262573bfd087567b16aa9d9e2920f2db1e9b3f0c743487698
  0963b0134415b3d74975c323146633ca4f9f710ee136add309250dbb77192ebf
  2d4a3c305fda7d99c62e3a8f1ba376729727a0fae4bdb00f4fe1710b363f7d03
  a135c5dd34cda2b9256d18f07b79b330a8eb1efebb71abc1926a8d4ae6b7669b
  f5e7f3ec326ae936f98b76447d89d7ea2f65427c7d6c11ebde1cf9d8a038fcd2
  93d80b04869a9052d581c5996a332dcede80d3295216534205b203d0dcf4f0d6
  ba257a62ed2e6a05bbc5256b23ef2148f247034e8d944b08b6e0a2d26f294d5a
  08d9e5eafb924c41710b1fede42bd88739fd29a7add96475d87b493db09b9426
  3b09fb68e9e2ea517395e9459c2c1ac4ba2dfe5153f8bee0da46b32569ed4eff
  5814a2a22e7f133aa853c36029e4209b286370b36863fef207174a10f8551b02
  3f4354f13b4afc17acce4901cecd0d66f02e940634ac8d2567d17da352cb653c
  79048a8acdf2202f79f20a49fbfad7652e4962061065516044109f9adaefb7cb
  f095d2b32817cc730a4b3755c74464add2630ca005de99d613d55fbf4d5e535c
  eef0cffe5357a206cd37d6a27fe06741ca15f96e8f266af91fc1e995c1fa88fc
  83d6f0c70fdba0aff8b1376aa2a14e6194fce1b9c7a6809f937368a8f9ea9702
  85b10d012b325e09ccca1c84fb8602f3bdffe49ef2f41236f08c01b1bc4e84f3
  3ea1510df38a421f0c769caeefddc3b5f7d75e35ff64dae1f9bfaa59e06af914
  480b59b0fdda89390bb2b28b5eaffd3ecea72a8fa429436dc7928e7a6f29fe09
  246b2d7af667fa07f1ee8a4bb5552e471ca6ff65af924e68638a037cc121ebcf
  133b3654e5cc1457c6e1a5dbb740830d20875fa91b4cc22b5fbe0ee4bd476ac7
  a109485ba06aa3a4ee0a1e858edd2119d130c126a3254f5117835355cd50322d
  072c2d2899a106fed577a34aafaae718324612fc2037db1409b84db868f4d7c0
  93f192a52c5276859e82ba325af182e17a5d829e1be958ad244deb59c656c3ce
  71172db76a4fab74c359529a7c7901952877653779498c82f1e5a339d6204942
  a92b032236be128204cb4a6aed94770524e16ea0af6b7a76d73bdf048865598c
  38c9e0b5a74f8d793431e783b328f2c8b2b2a5833bddfa7aee5f92b79323d938
  0ba95fdda82cdfc2ca87aabadaf771997a2ae8e8c8480d362f537a30c3228715
  30bbcb04c14fa20e292bf75aac3748125ec0a56c1cfa5dec965bea2884b969f1
  060e992679fd9bbf6e83db733b0ee506ec6527d98cb4472c6f18cac244e46ddf
  47499e37201404d77e5d09257fbb06ced8fbef56286f9e1af39f5d58047f7f40
)
backup=""
started=0
existed=()
hash_matches() {
  [ -f "$1" ] || return 1
  local actual
  actual="$(shasum -a 256 "$1")" || return 1
  [ "${actual%% *}" = "$2" ]
}
on_exit() {
  local code=$?
  trap - EXIT
  if [ "$code" -ne 0 ] && [ "$started" -eq 1 ]; then
    local i
    for i in "${!files[@]}"; do
      if [ "${existed[$i]}" -eq 1 ]; then
        cp "$backup/${files[$i]}" "$project/${files[$i]}" || printf 'Не восстановлен %s; резервная копия: %s\n' "${files[$i]}" "$backup" >&2
      else
        rm -f "$project/${files[$i]}"
      fi
    done
    printf 'Обновление остановлено; прежние исходники восстановлены.\n' >&2
  fi
  exit "$code"
}
trap on_exit EXIT
for i in "${!files[@]}"; do
  if ! hash_matches "$patch_root/${files[$i]}" "${hashes[$i]}"; then
    printf 'Неполное или повреждённое обновление: %s\n' "${files[$i]}" >&2
    exit 1
  fi
done
if [ "$#" -gt 1 ]; then printf 'Использование: bash Install_Update.command [папка Unity-проекта]\n' >&2;exit 1;fi
if [ "$#" -eq 1 ]; then project="$1";else
  printf 'Сначала закрой Unity. Выбери папку своего проекта с Assets и ProjectSettings.\n'
  project="$(osascript -e 'POSIX path of (choose folder with prompt "Выбери свой Unity-проект с Assets, Packages и ProjectSettings. Сначала закрой Unity.")')"
fi
if [ -z "$project" ] || [ ! -d "$project" ]; then printf 'Проект не выбран.\n' >&2;exit 1;fi
project="$(cd "$project" && pwd -P)"
if [ "$project" = "$patch_root" ] || [ ! -f "$project/ProjectSettings/ProjectVersion.txt" ] || [ ! -d "$project/Assets" ] || [ ! -f "$project/LocalPackages/com.silence.multiplayer/package.json" ]; then
  printf 'Выбери существующий Unity-проект SILENCE, а не папку обновления.\n' >&2;exit 1
fi
backup="$project/Library/Silence/SourceBackups/Update-0.5.1-$(date -u '+%Y%m%d-%H%M%S')-$$"
mkdir -p "$backup"
for i in "${!files[@]}"; do
  if [ -f "$project/${files[$i]}" ]; then
    existed[$i]=1
    mkdir -p "$(dirname "$backup/${files[$i]}")"
    cp "$project/${files[$i]}" "$backup/${files[$i]}"
  else
    existed[$i]=0
    printf '%s\n' "${files[$i]}" >> "$backup/new-files.txt"
  fi
done
started=1
for i in "${!files[@]}"; do
  mkdir -p "$(dirname "$project/${files[$i]}")"
  cp "$patch_root/${files[$i]}" "$project/${files[$i]}"
  if ! hash_matches "$project/${files[$i]}" "${hashes[$i]}";then printf 'Ошибка записи: %s\n' "${files[$i]}" >&2;exit 1;fi
done
printf 'SILENCE 0.5.1\nProject: %s\nBackup: %s\nFiles: %s\n' "$project" "$backup" "${#files[@]}" > "$project/Library/Silence/UpdateInstalled.txt"
started=0
printf '\nУстановлено SILENCE 0.5.1: %s проверенных файлов.\nПроект: %s\nBackup: %s\n' "${#files[@]}" "$project" "$backup"
printf 'Импортированные ассеты и .meta сохранены. Открой этот проект в Unity, дождись компиляции.\nДля исправления рук: Play в нынешнем мире; создавать новую копию не нужно.\nПодключение новых ассетов при необходимости: SILENCE → 28 Imported Textures and Human Motions.\n'
